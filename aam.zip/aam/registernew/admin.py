from django.contrib import admin
from .models import RegisterNewPerson
# Register your models here.

admin.site.register(RegisterNewPerson)